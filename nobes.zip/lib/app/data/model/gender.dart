class GenderModel {
  final bool isMan;
  final String gender;
  GenderModel(this.isMan, this.gender);
}
