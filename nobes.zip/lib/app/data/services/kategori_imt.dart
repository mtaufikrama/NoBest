class KategoriIMT {
  static const obesitas = 'obesity';
  static const kegemukkan = 'overweight';
  static const normal = 'normal';
  static const kurus = 'underweight';
}
