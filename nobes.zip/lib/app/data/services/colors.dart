import 'package:flutter/material.dart';

class Warna {
  static const primary = Color(0xFFD2DC02);
  static const secondary = Color(0xFF16B3AC);
  static const baseWhite = Color(0xFFE6E6E6);
  static const baseBlack = Color(0xFF242424);
}
