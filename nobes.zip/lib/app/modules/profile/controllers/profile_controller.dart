import 'package:get/get.dart';
import 'package:nobes/app/data/services/public.dart';

class ProfileController extends GetxController {
  //TODO: Implement ProfileController

  final getProfile = Publics.controller.getProfile;
  final getBahasa = Publics.controller.getBahasa;
  final getTutorial = Publics.controller.getTutorial;
}
